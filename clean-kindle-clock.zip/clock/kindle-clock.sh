#!/bin/sh
#
# Kindle Clock (portable rewrite of mattzzw/kindle-clock)
#
# Usage (via KUAL, or by hand):
#   sh kindle-clock.sh          -> "simple" mode (default, safe): Kindle UI keeps running,
#                                  clock is drawn on top. Keep the Kindle plugged in.
#   sh kindle-clock.sh saver    -> "saver" mode (experimental): stops the Kindle UI and
#                                  suspends between minutes. Exit = hold power button ~40s.
#
# Needs: jailbreak + KUAL + an fbink binary (MRInstaller, KOReader, etc.).
# If no fbink is found, it falls back to the built-in (ugly, small) `eips`.

MODE="${1:-simple}"

### ---------------- settings ----------------
CITY=""              # empty = auto-detect from your IP; or e.g. "Boston" or "New+York"
UNITS="u"            # u = Fahrenheit/US units, m = Celsius/metric
SHOW_WEATHER=1       # 0 = don't fetch weather
NTP_SERVER="pool.ntp.org"
SYNC_EVERY=3600      # seconds between time sync / weather refresh
MIN_BATTERY=10       # below this (and not charging) the clock quits
LOG="/mnt/us/clock.log"
### ------------------------------------------

DIR=$(cd "$(dirname "$0")" && pwd)
PIDFILE="/tmp/kindle-clock.pid"
MODEFILE="/tmp/kindle-clock.mode"

# keep the log small
if [ -f "$LOG" ] && [ "$(wc -c < "$LOG")" -gt 100000 ]; then : > "$LOG"; fi
log() { echo "$(date '+%Y-%m-%d_%H:%M:%S'): $*" >> "$LOG"; }

# only one copy at a time
if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE" 2>/dev/null)" 2>/dev/null; then
    log "already running, exiting"
    exit 0
fi
echo $$ > "$PIDFILE"
echo "$MODE" > "$MODEFILE"
log "---- start (mode=$MODE, model=$(cat /proc/usid 2>/dev/null | cut -c1-6)) ----"

### ---- find a working fbink ----
FBINK=""
for c in \
    /mnt/us/extensions/MRInstaller/bin/K5/fbink \
    /mnt/us/extensions/MRInstaller/bin/*/fbink \
    /mnt/us/koreader/fbink \
    /mnt/us/libkh/bin/fbink \
    /mnt/us/extensions/*/bin/fbink \
    /usr/local/bin/fbink \
    /usr/bin/fbink \
    "$(command -v fbink 2>/dev/null)"; do
    if [ -n "$c" ] && [ -f "$c" ] && "$c" -V >/dev/null 2>&1; then
        FBINK="$c"
        break
    fi
done
log "fbink: ${FBINK:-none (using eips)}"

### ---- find a TTF font ----
FONT=""
for f in \
    /usr/java/lib/fonts/Palatino-Regular.ttf \
    /usr/java/lib/fonts/Caecilia_LT_65_Medium.ttf \
    /usr/java/lib/fonts/Amazon-Ember-Regular.ttf \
    /usr/java/lib/fonts/*Regular*.ttf \
    /mnt/us/fonts/*.ttf; do
    if [ -f "$f" ]; then FONT="$f"; break; fi
done

### ---- screen width -> scale factor (everything was designed for 758px wide) ----
W=""
if [ -n "$FBINK" ]; then
    W=$("$FBINK" -e 2>/dev/null | sed -n 's/.*screenWidth=\([0-9][0-9]*\).*/\1/p' | head -n 1)
fi
case "$W" in ''|*[!0-9]*) W=758 ;; esac
sz() { echo $(( $1 * W / 758 )); }   # scale a PW2-sized number to this screen

### ---- helpers ----
batt() {
    b=$(lipc-get-prop com.lab126.powerd battLevel 2>/dev/null)
    if [ -z "$b" ]; then
        for f in /sys/devices/system/*battery*/*battery*/battery_capacity /sys/class/power_supply/*/capacity; do
            [ -r "$f" ] && b=$(cat "$f" 2>/dev/null) && break
        done
    fi
    echo "${b:-?}"
}
charging() { [ "$(lipc-get-prop com.lab126.powerd isCharging 2>/dev/null)" = "1" ]; }
wifi_up()  { [ "$(lipc-get-prop com.lab126.wifid cmState 2>/dev/null)" = "CONNECTED" ]; }

stop_ui() {
    if command -v stop >/dev/null 2>&1 && [ -d /etc/upstart ]; then
        for s in lab126_gui otaupd phd tmd x todo mcsd; do stop "$s" >/dev/null 2>&1; done
    else
        for s in framework pmond phd cmd tmd browserd webreaderd; do /etc/init.d/$s stop >/dev/null 2>&1; done
    fi
}

COND="---"
TEMP="---"
update_weather() {
    [ "$SHOW_WEATHER" = "1" ] || return
    command -v curl >/dev/null 2>&1 || return
    WEATHER=$(curl -s -f -m 8 "https://wttr.in/${CITY}?${UNITS}&format=%C,+%t")
    RC=$?
    log "weather: '$WEATHER' rc=$RC"
    if [ $RC -eq 0 ] && [ -n "$WEATHER" ]; then
        COND=${WEATHER%,*}
        TEMP=$(echo "${WEATHER##*,}" | sed 's/+//; s/^ *//')
    fi
}

sync_net() {
    NOWIFI=0
    if [ "$MODE" = "saver" ]; then
        lipc-set-prop com.lab126.cmd wirelessEnable 1 >/dev/null 2>&1
        n=0
        while ! wifi_up; do
            [ $n -gt 30 ] && break
            if [ "$(lipc-get-prop com.lab126.wifid cmState 2>/dev/null)" = "READY" ]; then
                wpa_cli -i wlan0 reconnect >/dev/null 2>&1
            fi
            sleep 1
            n=$((n + 1))
        done
    fi
    if wifi_up; then
        if command -v ntpdate >/dev/null 2>&1; then
            ntpdate -s "$NTP_SERVER" >/dev/null 2>&1
            log "ntpdate rc=$?"
        fi
        update_weather
    else
        NOWIFI=1
        log "no wifi"
    fi
    if [ "$MODE" = "saver" ]; then
        lipc-set-prop com.lab126.cmd wirelessEnable 0 >/dev/null 2>&1
    fi
    LAST_SYNC=$(date +%s)
}

clear_screen() {
    [ -n "$FBINK" ] || return
    "$FBINK" -q -f -c
    "$FBINK" -q -f -c
}

# put <size> <top> <row> <text> [extra fbink flags]
put() {
    if [ -n "$FONT" ]; then
        "$FBINK" -q -b $5 -m -t "regular=$FONT,size=$(sz "$1"),top=$(sz "$2"),bottom=0,left=0,right=0" "$4"
    else
        # no TTF available: built-in bitmap font, positioned by text row
        "$FBINK" -q -b $5 -m -y "$3" "$4"
    fi
}

draw() {
    TIME=$(date '+%H:%M')
    DATE=$(date '+%A, %B %d, %Y' | sed 's/ 0/ /')
    BAT=$(batt)
    if [ -n "$FBINK" ]; then
        put 150 10  4  "$TIME" "-c"
        put 20  410 10 "$DATE"
        put 20  510 12 "$COND"
        put 30  600 14 "$TEMP | Bat: ${BAT}%"
        [ "$NOWIFI" = "1" ] && put 12 700 16 "No Wifi"
        "$FBINK" -q -w -s
    else
        eips -c
        eips 3 8 "$TIME"
        eips 3 10 "$DATE"
        eips 3 12 "$COND  $TEMP"
        eips 3 14 "Bat: ${BAT}%"
    fi
}

sleep_to_next_minute() {
    s=$(date +%S | sed 's/^0//')
    s=${s:-0}
    secs=$((60 - s))
    [ $secs -lt 5 ] && secs=$((secs + 60))
    if [ "$MODE" = "saver" ]; then
        rtc=rtc1; [ -d /sys/class/rtc/rtc1 ] || rtc=rtc0
        if command -v rtcwake >/dev/null 2>&1 && [ -w /sys/power/state ]; then
            rtcwake -d "/dev/$rtc" -m no -s "$secs" >/dev/null 2>&1
            echo mem > /sys/power/state
            return
        fi
    fi
    sleep "$secs"
}

finish() {
    log "exiting (battery low or stopped)"
    rm -f "$PIDFILE"
    lipc-set-prop com.lab126.powerd preventScreenSaver 0 >/dev/null 2>&1
    if [ "$MODE" = "saver" ]; then
        # UI was stopped; a reboot is the most reliable way back
        reboot
    fi
    exit 0
}

### ---- start up ----
# refuse to start on a nearly empty battery
if [ "$(batt)" != "?" ] && [ "$(batt)" -lt "$MIN_BATTERY" ] && ! charging; then
    log "battery too low to start"
    [ -n "$FBINK" ] && "$FBINK" -q -c -m "Battery too low for clock - please charge"
    rm -f "$PIDFILE"
    exit 1
fi

[ -n "$FBINK" ] && "$FBINK" -q -c -f -m "Starting clock..."

[ "$MODE" = "saver" ] && { stop_ui; sleep 2; }

echo powersave > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 2>/dev/null
lipc-set-prop com.lab126.powerd preventScreenSaver 1 >/dev/null 2>&1

LAST_SYNC=0
NOWIFI=0
MIN_COUNT=0

while true; do
    # frontlight off (works on frontlit models; harmless elsewhere)
    lipc-set-prop com.lab126.powerd flIntensity 0 >/dev/null 2>&1

    # low-battery guard
    b=$(batt)
    if [ "$b" != "?" ] && [ "$b" -lt "$MIN_BATTERY" ] && ! charging; then
        [ -n "$FBINK" ] && "$FBINK" -q -c -m "Battery low - clock stopped"
        finish
    fi

    NOW=$(date +%s)
    if [ $((NOW - LAST_SYNC)) -ge "$SYNC_EVERY" ]; then
        sync_net
        clear_screen
    fi

    draw
    sleep_to_next_minute
done
