#!/bin/sh
# Stop the Kindle Clock and return to normal.

PIDFILE="/tmp/kindle-clock.pid"
MODEFILE="/tmp/kindle-clock.mode"

if [ -f "$PIDFILE" ]; then
    kill "$(cat "$PIDFILE")" 2>/dev/null
    rm -f "$PIDFILE"
fi

lipc-set-prop com.lab126.powerd preventScreenSaver 0 >/dev/null 2>&1

if [ "$(cat "$MODEFILE" 2>/dev/null)" = "saver" ]; then
    # the UI was stopped in saver mode; reboot brings it back reliably
    rm -f "$MODEFILE"
    reboot
else
    rm -f "$MODEFILE"
    # repaint the home screen
    lipc-set-prop com.lab126.appmgrd start app://com.lab126.booklet.home >/dev/null 2>&1
fi
